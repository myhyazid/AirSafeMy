<?php
require_once("../array.php") ;
require_once("../array_2.php") ;
require_once("../array_3.php") ;
require_once("../array_4.php") ;
require_once("KLConn.php") ;

echo ($area);
?>