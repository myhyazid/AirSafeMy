<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css"> 
<div class="panel panel-danger">
    <div align='center' class="panel-heading">Authorization Needed for sequence processing</div>
      <div class="panel-body">
             <form align='center' action='' method='POST'>
                <p>Authorization Needed for sequence processing</p>
                <p>Please input Auth Code to proceed  <input type='pass' id='email' name='email' /><br/>
                <br/>
               <input class='btn btn-danger' type='submit' name='submit' />
        </form>
        </div>
    </div>
</div>