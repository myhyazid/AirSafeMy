<?php
$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = 'Myhyazid211299';
$dbname = 'AirSafeMy';
$conn = mysql_connect($dbhost, $dbuser, $dbpass, $dbname);
if(! $conn )
{
  die('Could not connect: ' . mysql_error());
}
echo '<b>Connected successfully</b><br />';
?>